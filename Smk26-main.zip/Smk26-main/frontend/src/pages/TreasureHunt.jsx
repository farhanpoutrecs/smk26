import { useEffect, useState } from "react";
import * as Phosphor from "@phosphor-icons/react";
import { TH_CATEGORIES, CHECKPOINTS } from "../data/sports";
import { publicApi } from "../lib/api";
import { toast } from "sonner";

const MAP = "https://static.prod-images.emergentagent.com/jobs/cc4ea78b-0e96-4cb1-8140-80a8127210a4/images/45463ca105cb35464b727245d958acd21526b02873b6de8f5ac2ef259fea4bf8.png";

export default function TreasureHunt() {
  const [tab, setTab] = useState("overview");
  const [team, setTeam] = useState("");
  const [cat, setCat] = useState(TH_CATEGORIES[0].id);
  const [cp, setCp] = useState(CHECKPOINTS[0].id);
  const [code, setCode] = useState("");
  const [leaderboard, setLeaderboard] = useState([]);

  const load = async () => {
    const r = await publicApi.thLeaderboard();
    setLeaderboard(r.data);
  };
  useEffect(() => { load(); }, []);

  const onSubmit = async () => {
    if (!team) { toast.error("Sila masukkan nama pasukan"); return; }
    try {
      await publicApi.thSubmit({ team_name: team, category: cat, checkpoint_id: cp, code });
      toast.success(`+10 mata ditambah untuk ${team}`);
      setCode("");
      await load();
    } catch {
      toast.error("Gagal menghantar checkpoint");
    }
  };

  return (
    <div data-testid="treasure-hunt-page">
      <section className="relative overflow-hidden border-b border-[#2D3342]">
        <img src={MAP} alt="" className="w-full h-56 md:h-72 object-cover opacity-50" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/50 to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-end p-5 max-w-6xl mx-auto">
          <div className="text-xs font-bold uppercase tracking-[0.25em] text-[#F97316]">Signature Feature</div>
          <h1 className="font-display font-black text-4xl md:text-6xl uppercase leading-[0.9]">SMK26 Exploration<br/><span className="text-[#00D4AA]">Hunt</span> @ MAEPS</h1>
        </div>
      </section>

      <div className="px-4 py-6 max-w-6xl mx-auto">
        <div className="flex gap-2 overflow-x-auto pb-2" data-testid="th-tabs">
          {["overview","categories","rules","checkpoints","leaderboard","join"].map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              data-testid={`th-tab-${t}`}
              className={`flex-shrink-0 px-4 py-2 rounded-md border text-xs font-bold uppercase tracking-wider ${tab === t ? "bg-[#F97316] text-white border-[#F97316]" : "bg-[#12141A] text-[#94A3B8] border-[#2D3342]"}`}
            >
              {t === "overview" ? "Gambaran" : t === "categories" ? "Kategori" : t === "rules" ? "Peraturan" : t === "checkpoints" ? "Checkpoint" : t === "leaderboard" ? "Leaderboard" : "Sertai"}
            </button>
          ))}
        </div>

        {tab === "overview" && (
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4" data-testid="th-overview">
            {[
              { k: "Checkpoint", v: "10–14", c: "#00D4AA" },
              { k: "Mata/CP", v: "+10", c: "#F97316" },
              { k: "Bonus Kreativiti", v: "+5", c: "#FACC15" },
              { k: "Kategori", v: "4", c: "#22C55E" },
              { k: "Masa", v: "Timed", c: "#94A3B8" },
              { k: "Lokasi", v: "MAEPS", c: "#00D4AA" },
            ].map((it, i) => (
              <div key={i} className="bg-[#12141A] border border-[#2D3342] rounded-md p-5">
                <div className="text-xs uppercase tracking-[0.2em]" style={{ color: it.c }}>{it.k}</div>
                <div className="font-display font-black text-4xl mt-1">{it.v}</div>
              </div>
            ))}
          </div>
        )}

        {tab === "categories" && (
          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4" data-testid="th-categories">
            {TH_CATEGORIES.map(c => {
              const Icon = Phosphor[c.icon] || Phosphor.MapTrifold;
              return (
                <div key={c.id} className="bg-[#12141A] border border-[#2D3342] rounded-md p-5">
                  <div className="w-10 h-10 rounded-md flex items-center justify-center mb-3" style={{ background: `${c.color}18`, color: c.color }}>
                    <Icon size={22} weight="bold" />
                  </div>
                  <div className="font-display font-black text-xl uppercase">{c.name}</div>
                  <p className="text-sm text-[#94A3B8] mt-1">{c.description}</p>
                  <div className="mt-3 inline-block text-[10px] uppercase tracking-[0.2em] px-2 py-1 rounded border" style={{ color: c.color, borderColor: `${c.color}44` }}>{c.checkpoints} Checkpoint</div>
                </div>
              );
            })}
          </div>
        )}

        {tab === "rules" && (
          <div className="mt-6 bg-[#12141A] border border-[#2D3342] rounded-md p-6 text-[#94A3B8] text-sm space-y-2" data-testid="th-rules">
            {[
              "Pasukan 3–5 orang. Individual dibenarkan untuk Fun Open.",
              "Imbas QR di setiap checkpoint untuk merekod ketibaan.",
              "Setiap checkpoint ada tugasan: puzzle, foto, video atau aktiviti fizikal.",
              "+10 mata setiap checkpoint disahkan. +5 bonus untuk jawapan kreatif.",
              "Satu checkpoint bonus tersembunyi — cari mystery code!",
              "Kod misteri layak untuk cabutan bertuah selepas acara.",
            ].map((r,i)=>(<div key={i} className="flex gap-2"><span className="text-[#F97316]">{String(i+1).padStart(2,"0")}</span>{r}</div>))}
          </div>
        )}

        {tab === "checkpoints" && (
          <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3" data-testid="th-checkpoints">
            {CHECKPOINTS.map(c => (
              <div key={c.id} className="bg-[#12141A] border border-[#2D3342] rounded-md p-4 hover:border-[#00D4AA] transition-colors">
                <div className="font-display font-black text-2xl text-[#F97316]">{c.id}</div>
                <div className="text-xs text-[#94A3B8] mt-1">{c.clue}</div>
              </div>
            ))}
          </div>
        )}

        {tab === "leaderboard" && (
          <div className="mt-6" data-testid="th-leaderboard">
            {leaderboard.length === 0 ? (
              <div className="text-center text-[#94A3B8] py-10">Belum ada penyertaan. Jadilah pasukan pertama!</div>
            ) : (
              <div className="bg-[#12141A] border border-[#2D3342] rounded-md overflow-hidden">
                {leaderboard.map((t, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 border-b border-[#2D3342] last:border-b-0" data-testid={`leaderboard-row-${i}`}>
                    <div className="font-display font-black text-xl w-8 text-[#00D4AA]">#{i+1}</div>
                    <div className="flex-1">
                      <div className="font-semibold">{t.team_name}</div>
                      <div className="text-[10px] uppercase tracking-[0.2em] text-[#94A3B8]">{t.category}</div>
                    </div>
                    <div className="font-display font-black text-2xl text-[#F97316]">{t.points}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === "join" && (
          <div className="mt-6 bg-[#12141A] border border-[#2D3342] rounded-md p-5 space-y-3" data-testid="th-join">
            <label className="block">
              <span className="text-xs uppercase tracking-[0.2em] text-[#94A3B8]">Nama Pasukan</span>
              <input value={team} onChange={(e)=>setTeam(e.target.value)} data-testid="th-team-input" className="mt-1 w-full bg-[#0A0A0A] border border-[#2D3342] rounded-md px-4 py-3 text-white focus:border-[#00D4AA] focus:outline-none" />
            </label>
            <label className="block">
              <span className="text-xs uppercase tracking-[0.2em] text-[#94A3B8]">Kategori</span>
              <select value={cat} onChange={(e)=>setCat(e.target.value)} data-testid="th-category-select" className="mt-1 w-full bg-[#0A0A0A] border border-[#2D3342] rounded-md px-4 py-3 text-white">
                {TH_CATEGORIES.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="text-xs uppercase tracking-[0.2em] text-[#94A3B8]">Checkpoint</span>
              <select value={cp} onChange={(e)=>setCp(e.target.value)} data-testid="th-checkpoint-select" className="mt-1 w-full bg-[#0A0A0A] border border-[#2D3342] rounded-md px-4 py-3 text-white">
                {CHECKPOINTS.map(c=><option key={c.id} value={c.id}>{c.id} — {c.clue}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="text-xs uppercase tracking-[0.2em] text-[#94A3B8]">Mystery Code (pilihan)</span>
              <input value={code} onChange={(e)=>setCode(e.target.value)} placeholder="cth: FIREFLY-01" data-testid="th-code-input" className="mt-1 w-full bg-[#0A0A0A] border border-[#2D3342] rounded-md px-4 py-3 text-white focus:border-[#F97316] focus:outline-none" />
            </label>
            <button onClick={onSubmit} data-testid="th-submit-btn" className="w-full bg-[#F97316] hover:bg-[#EA580C] text-white font-bold py-3 rounded-md uppercase tracking-wider">Hantar Checkpoint</button>
          </div>
        )}
      </div>
    </div>
  );
}
